import copy
import json
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from emulation.experiment import environmentSpec, pathPorts, utilization, validate
from emulation.matched import PAIRS, TABLES, MatchedRouting
from emulation.ospf import PATHS, OSPFNetwork
from emulation.tests.test_experiment import request
from emulation.workloads import schedule


class MatchedTests(unittest.TestCase):
    def testStationaryPairedSchedulesAndVersion(self):
        for scenario, capacities in (("path0", [2, 20]), ("path1", [20, 2]), ("low", [20, 20])):
            phases = schedule(1000, scenario, 3, "matched")
            self.assertEqual(phases, schedule(1000, scenario, 3, "ospf"))
            self.assertTrue(all(p["path_capacity_mbps"] == capacities for p in phases))
            self.assertEqual(len({p["offered_mbps"] for p in phases}), 1)
            self.assertEqual(len({p["background_mbps"] for p in phases}), 1)
            self.assertEqual({p["background_path"] for p in phases}, {0})
        self.assertEqual(environmentSpec("matched"), environmentSpec("ospf"))
        self.assertEqual(environmentSpec("matched")[0]["version"], 4)
        self.assertEqual(environmentSpec("sdn")[0]["version"], 4)
        for mode in ("ospf", "matched"):
            validate({**request(), "mode": mode})
            for scenario in ("alternating", "burst", "overload"):
                with self.assertRaises(ValueError):
                    validate({**request(), "mode": mode, "scenario": scenario})

    def testUtilizationUsesActualCapacity(self):
        before, after = {}, {}
        for ports in pathPorts():
            for node, port in ports:
                key = f"{node}-eth{port}"
                before[key] = {"monotonic_seconds": 1, "tx_bytes": 0}
                after[key] = {"monotonic_seconds": 2, "tx_bytes": 250000}
        self.assertEqual(utilization(before, after, [2, 20])[0], [1, 0.1])

    def testShapingReadbackAndHoldNeverReconfigures(self):
        network = OSPFNetwork()
        rates = {}

        def command(node, args):
            if "change" in args:
                rates[node, args[4]] = args[args.index("rate") + 1][:-4]
                return ""
            return f"class htb 5:1 root leaf 10: prio 0 rate {rates[node, args[-1]]}Mbit ceil {rates[node, args[-1]]}Mbit burst 15Kb cburst 1600b \n"

        with patch.object(network, "command", side_effect=command) as run:
            self.assertEqual(len(network.shape([2, 20])), 8)
            run.reset_mock()
            network.shape()
            self.assertTrue(all("change" not in c.args[1] for c in run.call_args_list))
            rates["access1", "access1-eth1"] = "20"
            with self.assertRaisesRegex(RuntimeError, "capacity"):
                network.shape()
        for bad in ([True, 20], [0, 20], [2], "2"):
            with self.assertRaises(ValueError):
                network.shape(bad)

    def routing(self):
        network = OSPFNetwork()
        lab = SimpleNamespace(network=network, checkController=Mock())
        routing = MatchedRouting(lab)
        rules, routes = {}, {}

        def command(node, args):
            if args[1:3] == ["-j", "rule"]:
                return json.dumps([r for (n, _), r in rules.items() if n == node])
            if args[1:3] == ["-j", "route"]:
                return json.dumps([r for (n, _), r in routes.items() if n == node])
            table = int(args[args.index("table") + 1])
            target = rules if args[1] == "rule" else routes
            if args[2] == "del":
                del target[node, table]
            elif args[1] == "rule":
                target[node, table] = {
                    "table": table,
                    "priority": table,
                    "src": args[args.index("from") + 1],
                    "dst": args[args.index("to") + 1],
                }
            else:
                target[node, table] = {
                    "table": table,
                    "dst": args[3],
                    "protocol": "static",
                    "dev": args[args.index("dev") + 1],
                    "gateway": args[args.index("via") + 1],
                }
            return ""

        def path(source, destination):
            action = routing.action if source in ("h1", "h3") and routing.action is not None else 0
            nodes = PATHS[action] if source < destination else tuple(reversed(PATHS[action]))
            return {"nodes": [source, *nodes, destination], "action": action}

        network.command = Mock(side_effect=command)
        network.routePath = Mock(side_effect=path)
        return routing, rules, routes

    def testWholeBidirectionalRouteHoldRestoreAndNoBackgroundMutation(self):
        routing, rules, routes = self.routing()
        for action in (0, 1, 0):
            result = routing.change(action)
            self.assertTrue(result["changed"])
            self.assertEqual(len(rules), 6)
            self.assertEqual(len(routes), 6)
            snapshot = copy.deepcopy((rules, routes))
            self.assertFalse(routing.change(action)["changed"])
            self.assertEqual(snapshot, (rules, routes))
            for rule in rules.values():
                self.assertEqual({rule["src"], rule["dst"]}, {"10.78.8.2/32", "10.78.10.2/32"})
        routing.close()
        routing.close()
        self.assertFalse(rules or routes)
        self.assertTrue(
            all("flush" not in c.args[1] for c in routing.network.command.call_args_list)
        )
        for pair in PAIRS:
            routing.network.routePath.assert_any_call(*pair)

    def testOccupiedTableAndForeignCleanupRefused(self):
        routing, rules, routes = self.routing()
        routes["core", TABLES[0]] = {"table": TABLES[0], "dst": "192.0.2.0/24"}
        with self.assertRaisesRegex(RuntimeError, "occupied"):
            routing.change(1)
        self.assertFalse(routing.owned)
        self.assertEqual(len(routes), 1)
        routes.clear()
        routing.change(1)
        rules["access1", TABLES[0]]["src"] = "192.0.2.1"
        with self.assertRaisesRegex(RuntimeError, "readback"):
            routing.change(1)
        with self.assertRaisesRegex(RuntimeError, "foreign"):
            routing.close()
        self.assertEqual(rules["access1", TABLES[0]]["src"], "192.0.2.1")

    def testPartialInstallFailureRestores(self):
        routing, rules, routes = self.routing()
        command = routing.network.command.side_effect

        def fail(node, args):
            if args[1:3] == ["rule", "add"]:
                raise RuntimeError("injected failure")
            return command(node, args)

        routing.network.command.side_effect = fail
        with self.assertRaisesRegex(RuntimeError, "injected"):
            routing.change(1)
        self.assertFalse(rules or routes or routing.owned)
